from cybervpn import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time
import sys
from telethon.sync import TelegramClient
import sqlite3

#############################################################################
###                            VLESS CREATE (RESELLER)                    ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'create-vless-member'))
async def create_vless(event):
    async def create_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**➽ Username :**')
            user_msg = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_msg.raw_text

            # Cek jika username mengandung huruf kapital
            if any(char.isupper() for char in user):
                await event.respond("**🗿 Proses dibatalkan !\n\n⛔ Username tidak boleh mengandung huruf kapital !!!**")
                return  # Hentikan proses jika ada huruf kapital

            # Cek jika username sudah ada
            cmd_check_user = f'/usr/local/bin/bot/check-xray-user "{user}"'
            print(f"Running command: {cmd_check_user}")  # Debugging
            try:
                check_output = subprocess.check_output(cmd_check_user, shell=True, timeout=10).decode("utf-8").strip()
                print(f"Command output: {check_output}")  # Debugging
                if "already exists" in check_output.lower():
                    await event.respond("**⛔ Proses dibatalkan !\n\n🗿 Username sudah tersedia.\n🔄 Silahkan mulai ulang bot /start !!!**")
                    return  # Hentikan proses jika username sudah ada
            except subprocess.TimeoutExpired:
                await event.respond("**✘ Proses dibatalkan: Timeout saat mengecek username.**")
                return
            except subprocess.CalledProcessError as e:
                print(f'Command failed with return code {e.returncode}: {e.output.decode("utf-8")}')
                await event.respond(f"**Terjadi kesalahan saat mengecek username: {e.output.decode('utf-8')}**")
                return
            except Exception as e:
                print(f'Error checking user: {e}')
                await event.respond(f"**Terjadi kesalahan saat mengecek username: {e}**")
                return

        async with bot.conversation(chat) as pw_conv:
            await event.respond("**➽ Limit Quota (GB):**")
            pw_msg = await pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = pw_msg.raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline("15 Hari = 5000", b"15")],
                [Button.inline("30 Hari = 10000", b"30")],
                [Button.inline("60 Hari = 15000", b"60")],
                [Button.inline("90 Hari = 25000", b"90")]
            ])
            exp_msg = await exp_conv.wait_event(events.CallbackQuery)
            exp = exp_msg.data.decode("ascii")

            # Menentukan harga berdasarkan pilihan user
            if exp == "15":
                harga = 5000
            elif exp == "30":
                harga = 10000
            elif exp == "60":
                harga = 15000
            elif exp == "90":
                harga = 25000
            else:
                await event.respond("**✘ Pilihan tidak valid.**")
                return

        # Panggil fungsi untuk memproses saldo pengguna
        saldo_tercukupi = await process_user_balance_vless(event, user_id, harga)
        
        if not saldo_tercukupi:  # Jika saldo tidak mencukupi, hentikan proses
            return

        cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" | /usr/local/bin/bot/add-vless-bot'
        try:
            a = subprocess.check_output(cmd, shell=True, timeout=10).decode("utf-8")
        except subprocess.TimeoutExpired:
            await event.respond("**✘ Proses dibatalkan: Timeout saat membuat akun.**")
            return
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"Terjadi kesalahan: {e}\nSubproses output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        x = [x.group() for x in re.finditer("vless://(.*)", a)]
        print(x)
        uuid = re.search("vless://(.*?)@", x[0]).group(1)
        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━**
          🍀 𝐗𝐑𝐀𝐘 𝐕𝐋𝐄𝐒𝐒 𝐂𝐑𝐄𝐀𝐓𝐄𝐃 🍀 
**━━━━━━━━━━━━━━━━━━━━━**
➱ Remarks   : {user}
➱ Domain    : {DOMAIN}
➱ Quota     : {pw} GB
➱ Port TLS  : 443
➱ Port NTLS : 80, 8880
➱ User ID   : {uuid}
➱ Alter ID  : 0
➱ Security  : auto
➱ Path WS   : /vlessws
➱ Path gRPC : vless-grpc
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VLESS WS TLS ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[0]}```
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VLESS WS NTLS ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[1].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VLESS gRPC ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[2].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━**
** ➽ 𝐄𝐗𝐏𝐈𝐑𝐄𝐃 𝐀𝐂𝐂𝐎𝐔𝐍𝐓 : {later}**
**━━━━━━━━━━━━━━━━━━━━━**
"""
        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


#############################################################################
###                              RENEW VLESS (RESELLER)                   ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'renew-vless-member'))
async def ren_vless(event):
    async def ren_vless_(event):

        # Meminta username pengguna
        async with bot.conversation(chat) as user_conv:
            await event.respond('**❐ INFO :\nHarap Input username\nakun 𝗩𝗟𝗘𝗦𝗦 dengan benar,\nJika salah input itu resiko.\n\n➥ Silahkan Input Username :**')

            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text
            
        async with bot.conversation(chat) as exp_conv:
            await event.respond(
                "**❏ Choose Expiry Day ❏**",
                buttons=[
                    [Button.inline("15 Hari = 5000", b"15")],
                    [Button.inline("30 Hari = 10000", b"30")],
                    [Button.inline("60 Hari = 15000", b"60")],
                    [Button.inline("90 Hari = 25000", b"90")]
                ]
            )
            exp = await exp_conv.wait_event(events.CallbackQuery)
            expp = exp.data.decode("ascii")


        # Validasi input username
        if not user:
            await event.respond("**✘ Username tidak boleh kosong.**")
            return

        # Menentukan harga berdasarkan pilihan
        harga_map = {
            "15": 5000,
            "30": 10000,
            "60": 15000,
            "90": 25000
        }
        harga = harga_map.get(expp)
        if not harga:
            await event.respond("**✘ Pilihan tidak valid.**")
            return

        # Memproses saldo pengguna
        saldo_tercukupi = await process_user_balance_vless(event, user_id, harga)
        if not saldo_tercukupi:
            return

        cmd = f'printf "%s\n" "{user}" "{expp}" | /usr/local/bin/bot/renew-vless-bot'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**✘ User Not Found**")
        else:
            msg = f"""**{a}**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await ren_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


#############################################################################
###                             VLESS CHECK (RESELLER)                    ###
#############################################################################	
# CEK member VLESS
@bot.on(events.CallbackQuery(data=b'cek-membervl-member'))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'bash cek-mvs'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""

{z}

**Shows Users from databases**
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await cek_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


#############################################################################
###                            VLESS DELETE (RESELLER)                    ###
#############################################################################	
@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
	async def delete_vless_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Crate Premium Account`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" | del-vless'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**Successfully Deleted**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#############################################################################
###                           VLESS TRIAL 1 JAM (RESELLER)                ###
#############################################################################	
@bot.on(events.CallbackQuery(data=b'trial-vless-member'))
async def trial_vless(event):
    async def trial_vless_(event):
        cmd = f'printf "%s\n" "trial`</dev/urandom tr -dc a-z0-9 | head -c4`" "1" | /usr/local/bin/bot/add-vless-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**✘ User Already Exist**")
        else:
            # Mengganti masa aktif menjadi 1 jam
            now = DT.datetime.now()
            later = now + DT.timedelta(hours=1)  # Masa aktif 1 jam
            x = [x.group() for x in re.finditer("vless://(.*)", a)]
            print(x)
            remarks = re.search("#(.*)", x[0]).group(1)
            uuid = re.search("vless://(.*?)@", x[0]).group(1)
            
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━**
          🍀 𝐗𝐑𝐀𝐘 𝐕𝐋𝐄𝐒𝐒 𝐓𝐑𝐈𝐀𝐋 🍀 
**━━━━━━━━━━━━━━━━━━━━━**
➱ Remarks   : {remarks}
➱ Domain    : {DOMAIN}
➱ Port TLS  : 443
➱ Port NTLS : 80
➱ User ID   : {uuid}
➱ Network   : ws
➱ Path WS   : /vlessws
➱ Path gRPC : vless-grpc
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VLESS WS TLS ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[0]}```
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VLESS WS NTLS ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[1].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VLESS gRPC ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[2].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━**
** ➽ 𝐄𝐗𝐏𝐈𝐑𝐄𝐃 𝐀𝐂𝐂𝐎𝐔𝐍𝐓 : {later.strftime('%H:%M:%S')}**
**━━━━━━━━━━━━━━━━━━━━━**
        """
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await trial_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

#############################################################################
###                          VLESS TRIAL 3 jam (RESELLER)                 ###
#############################################################################	
@bot.on(events.CallbackQuery(data=b'trial1-vless-member'))
async def trial_vless1(event):
    async def trial_vless1_(event):

        # output cmd
        cmd = f'printf "%s\n" "trial`</dev/urandom tr -dc a-z0-9 | head -c4`" "1" | /usr/local/bin/bot/add-vless-bot'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**✘ User Already Exist**")
        else:
            # Mengganti masa aktif menjadi 3 jam
            now = DT.datetime.now()
            later = now + DT.timedelta(hours=3)  # Masa aktif 3 jam
            x = [x.group() for x in re.finditer("vless://(.*)", a)]
            print(x)
            remarks = re.search("#(.*)", x[0]).group(1)
            uuid = re.search("vless://(.*?)@", x[0]).group(1)
            
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━**
          🍀 𝐗𝐑𝐀𝐘 𝐕𝐋𝐄𝐒𝐒 𝐓𝐑𝐈𝐀𝐋 🍀 
**━━━━━━━━━━━━━━━━━━━━━**
➱ Remarks   : {remarks}
➱ Domain    : {DOMAIN}
➱ Port TLS  : 443
➱ Port NTLS : 80
➱ User ID   : {uuid}
➱ Network   : ws
➱ Path WS   : /vless
➱ Path gRPC : vless-service
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VMESS WS TLS ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[0]}```
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VMESS WS NTLS ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[1].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VMESS gRPC ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[2].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━**
** ➽ 𝐄𝐗𝐏𝐈𝐑𝐄𝐃 𝐀𝐂𝐂𝐎𝐔𝐍𝐓 : {later.strftime('%H:%M:%S')}**
**━━━━━━━━━━━━━━━━━━━━━**
        """
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await trial_vless1_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')
        
#############################################################################
###                             MENU VLESS (RESELLER)                     ###
#############################################################################	
@bot.on(events.CallbackQuery(data=b'vless-member'))
async def vless(event):
    async def vless_(event):
        inline = [
            [Button.inline("Create VLess", "create-vless-member"),
            Button.inline("Renew VLess", "renew-vless-member")],
            [Button.inline("Trial 1 Jam", "trial-vless-member"),
            Button.inline("Trial 3 Jam", "trial1-vless-member")],
            [Button.inline("🔙 Back To Menu", "menu")],
]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
𝚇𝚛𝚊𝚢 𝚅𝚕𝚎𝚜𝚜 𝙼𝚎𝚗𝚞
- Vless WS TLS
- Vless WS NTLS
- Vless gRPC TLS

𝚁𝚞𝚕𝚎𝚜:
- Max 2 Login
- Max 3x Peringatan (Penggantian UUID)
- Peringatan 4x Banned
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

