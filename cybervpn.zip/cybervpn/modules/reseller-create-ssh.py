from cybervpn import *
import subprocess
import datetime as DT
import sys
from telethon.sync import TelegramClient
import sqlite3


@bot.on(events.CallbackQuery(data=b'create-ssh-member'))
async def create_ssh(event):
    user_id = str(event.sender_id)

    async def create_ssh_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**➽ Username :**')
            user_msg = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_msg).raw_text

            # Cek apakah username sudah ada
            try:
                subprocess.check_output(f'id {user}', shell=True)
                await event.respond(f"**🗿 Username `{user}` sudah tersedia.\nSilahkan batalkan dan mulai ulang bot /start**", buttons=[
                    [Button.inline("Batalkan", b"cancel")]  # Hanya 1 button untuk membatalkan
                ])
                choice_msg = await user_conv.wait_event(events.CallbackQuery)
                choice = choice_msg.data.decode("ascii")

                if choice == "cancel":
                    await event.respond("**✘ Pembuatan akun dibatalkan.**")
                    return  # Hentikan proses setelah pembatalan
            except subprocess.CalledProcessError:
                pass  # Username belum ada, lanjutkan proses

        async with bot.conversation(chat) as pw_conv:
            await event.respond("**➽ Password :**")
            pw_msg = pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw_msg).raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond("**❏ Choose Expiry Day ❏**", buttons=[
                    [Button.inline("15 Hari = 5000", b"15")],
                    [Button.inline("30 Hari = 10000", b"30")],
                    [Button.inline("60 Hari = 15000", b"60")],
                    [Button.inline("90 Hari = 25000", b"90")]
            ])
            exp_msg = exp_conv.wait_event(events.CallbackQuery)
            exp = (await exp_msg).data.decode("ascii")

            # Menentukan harga berdasarkan pilihan user
            if exp == "15":
                harga = 5000
            elif exp == "30":
                harga = 10000
            elif exp == "60":
                harga = 15000
            elif exp == "90":
                harga = 25000
            else:
                await event.respond("**✘ Pilihan tidak valid.**")
                return

        # Panggil fungsi untuk memproses saldo pengguna
        saldo_tercukupi = await process_user_balance_ssh(event, user_id, harga)
        
        if not saldo_tercukupi:  # Jika saldo tidak mencukupi, hentikan proses
            return

        # Lanjutkan dengan eksekusi perintah useradd dan pesan respons
        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**✘ Sorry, User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
**━━━━━━━━━━━━━━━━━━━**
 ❐ 𝙎𝙎𝙃 𝘼𝘾𝘾𝙊𝙐𝙉𝙏 𝘾𝙍𝙀𝘼𝙏𝙀𝘿 ❐  
**━━━━━━━━━━━━━━━━━━━**
**» Hostname         :** `{DOMAIN}`
**» Username         :** `{user.strip()}`
**» Password         :** `{pw.strip()}`
**━━━━━━━━━━━━━━━━━**
**» Port OpenSSH     :** `22, 3303, 443`
**» Port DNSTT       :** `5300`
**» Port Dropbear    :** `109, 143, 69, 111`
**» Port WS HTTP     :** `80, 2080, 2082`
**» Udp Custom       :** `1-65535, 54-1600, 1-52, 800-3633`
**» Port WS HTTPS    :** `443`
**» Port SSL/TLS/SNI :** `443`
**» Proxy Squid      :** `8888`
**» BadVPN UDP       :** `7300`
**━━━━━━━━━━━━━━━━━**
**» Payload SSH WS   :** `GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» Payload OVPN     :** `GET /ovpn HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» PORT OVPN        :** `1194 TCP / 2200 UDP`
**» OpenVPN TCP      :** `http://{DOMAIN}:8081/tcp.ovpn`
**» OpenVPN UDP      :** `http://{DOMAIN}:8081/udp.ovpn`
**━━━━━━━━━━━━━━━━━━━**
**➽ Expiry:** `{later}`
**━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await create_ssh_(event)
        else:
            await event.answer(f'✘ Akses Ditolak.!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')
