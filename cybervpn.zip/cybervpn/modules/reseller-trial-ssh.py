from cybervpn import *
import subprocess
import datetime as DT
import random

@bot.on(events.CallbackQuery(data=b'skt-trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)
    async def trial_ssh_(event):
        user = "Tested" + str(random.randint(100, 1000))
        pw = "1"
        exp = "2 hours"  # Masa aktif 2 jam

        # Format tanggal dengan waktu untuk masa aktif 2 jam
        exp_time = (DT.datetime.now() + DT.timedelta(hours=2)).strftime('%Y-%m-%d %H:%M:%S')
        cmd = f'useradd -e "{exp_time}" -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'

        try:
            # Logging perintah untuk debugging
            print(f"Running command: {cmd}")
            result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
            print(f"Command output: {result.decode('utf-8')}")
        except subprocess.CalledProcessError as e:
            error_msg = e.output.decode('utf-8')
            print(f"Error: {error_msg}")
            await event.respond(f"**Failed to create user:**\n{error_msg}")
            return
        except Exception as e:
            print(f"Unexpected error: {e}")
            await event.respond(f"**Unexpected error occurred:** {e}")
            return
        else:
            now = DT.datetime.now()
            later = now + DT.timedelta(hours=2)
            msg = f"""
**━━━━━━━━━━━━━━━━━━━**
  𝗦𝗦𝗛 𝗧𝗥𝗜𝗔𝗟 𝗖𝗥𝗘𝗔𝗧𝗘𝗗
**━━━━━━━━━━━━━━━━━━━**
**» Hostname         :** `{DOMAIN}`
**» Username         :** `{user.strip()}`
**» Password         :** `{pw.strip()}`
**━━━━━━━━━━━━━━━━━**
**» Port OpenSSH     :** `22, 3303, 443`
**» Port DNSTT       :** `5300`
**» Port Dropbear    :** `109, 143, 69, 111`
**» Port WS HTTP     :** `80, 2080, 2082`
**» Udp Custom       :** `1-65535, 54-1600, 1-52, 800-3633`
**» Port WS HTTPS    :** `443`
**» Port SSL/TLS/SNI :** `443`
**» Proxy Squid      :** `8888`
**» BadVPN UDP       :** `7300`
**━━━━━━━━━━━━━━━━━**
**» Payload SSH WS   :** `GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» Payload OVPN     :** `GET /ovpn HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**━━━━━━━━━━━━━━━━━**
**» PORT OVPN        :** `1194 TCP / 2200 UDP`
**» OpenVPN TCP      :** `http://{DOMAIN}:8081/tcp.ovpn`
**» OpenVPN UDP      :** `http://{DOMAIN}:8081/udp.ovpn`
**━━━━━━━━━━━━━━━━━━━**
**➽ Expiry:** `{later.strftime('%H:%M:%S')}`
**━━━━━━━━━━━━━━━━━━━**
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await trial_ssh_(event)
        else:
            await event.answer(f"Akses Ditolak...!!", alert=True)
    except Exception as e:
        print(f"Error: {e}")
