from cybervpn import *
from telethon import events, Button
import requests

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    sender = await event.get_sender()
    user_id = str(event.sender_id)
    sender_username = sender.username

    if check_user_registration(user_id):
        try:
            s = 'bash /usr/local/bin/bot/menu-reseller'
            m = subprocess.check_output(s, shell=True).decode("utf-8")
            o = 'bash /usr/local/bin/bot/menu-admin'
            z = subprocess.check_output(o, shell=True).decode("utf-8")
            skt_saldo_admin, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("𝗦𝗦𝗛 𝗪𝗦", "ssh")],
                    [Button.inline("𝗩𝗠𝗘𝗦𝗦 𝗪𝗦", "vmess-member"), Button.inline("𝗩𝗟𝗘𝗦𝗦 𝗪𝗦", "vless-member")],
                    [Button.inline("𝗧𝗥𝗢𝗝𝗔𝗡 𝗪𝗦", "trojan-member")],
                    [Button.inline("💻 𝗙𝗘𝗔𝗧𝗨𝗥𝗘 𝗠𝗔𝗡𝗔𝗚𝗘 💻", "skt-setting-reseller")],
                    [Button.inline("➕ 𝐓𝐎𝐏𝐔𝐏 𝐒𝐀𝐋𝐃𝐎 𝐁𝐎𝐓 ➕", "topup")]
                ]

                member_msg = f"""
**{m}**
```👤 𝗨𝗦𝗘𝗥𝗡𝗔𝗠𝗘  : @{sender_username}
🧙‍♂️ 𝗠𝗬 𝗜𝗗      : {user_id}
👾 𝗠𝗬 𝗦𝗔𝗟𝗗𝗢  : Rp {skt_saldo_admin}```
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)

            elif level == "admin":
                admin_inline = [
                    [Button.inline("𝗦𝗦𝗛 𝗪𝗦", "ssh"), Button.inline("𝗩𝗠𝗘𝗦𝗦 𝗪𝗦", "vmess")],
                    [Button.inline("𝗧𝗥𝗢𝗝𝗔𝗡 𝗪𝗦", "trojan"), Button.inline("𝗩𝗟𝗘𝗦𝗦 𝗪𝗦", "vless")],
                    [Button.inline("💻 𝗙𝗘𝗔𝗧𝗨𝗥𝗘 𝗠𝗔𝗡𝗔𝗚𝗘 💻", "skt-setting-admin")]
                ]

                admin_msg = f"""
{z}
```💰 𝕊𝕚𝕤𝕒 𝕊𝕒𝕝𝕕𝕠  : Rp {skt_saldo_admin}
🧾 𝕋𝕠𝕥𝕒𝕝 ℝ𝕖𝕤𝕖𝕝𝕝𝕖𝕣  : {get_user_count()} Orang```
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        # Pesan tanpa tombol inline
        await event.reply(
            '🗿 **Sorry, Anda belum terdaftar, silahkan register di** [SaputraTech](https://t.me/SaputraTech).'
        )