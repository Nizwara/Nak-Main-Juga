from cybervpn import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time
import sys
from telethon.sync import TelegramClient
import sqlite3

#############################################################################
###                             VLESS CREATE (ADMIN)                      ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
    async def create_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**➽ Username :**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        
         # Cek jika username mengandung huruf kapital
            if any(char.isupper() for char in user):
                await event.respond("**🗿 Proses dibatalkan !\n\n⛔ Username tidak boleh mengandung huruf kapital !!!**")
                return  # Hentikan proses jika ada huruf kapital

            # Cek jika username sudah ada
            cmd_check_user = f'/usr/local/bin/bot/check-xray-user "{user}"'
            print(f"Running command: {cmd_check_user}")  # Debugging
            try:
                check_output = subprocess.check_output(cmd_check_user, shell=True, timeout=10).decode("utf-8").strip()
                print(f"Command output: {check_output}")  # Debugging
                if "already exists" in check_output.lower():
                    await event.respond("**⛔ Proses dibatalkan !\n\n🗿 Username sudah tersedia.\n🔄 Silahkan mulai ulang bot /start !!!**")
                    return  # Hentikan proses jika username sudah ada
            except subprocess.TimeoutExpired:
                await event.respond("**✘ Proses dibatalkan: Timeout saat mengecek username.**")
                return
            except subprocess.CalledProcessError as e:
                print(f'Command failed with return code {e.returncode}: {e.output.decode("utf-8")}')
                await event.respond(f"**Terjadi kesalahan saat mengecek username: {e.output.decode('utf-8')}**")
                return
            except Exception as e:
                print(f'Error checking user: {e}')
                await event.respond(f"**Terjadi kesalahan saat mengecek username: {e}**")
                return
        
        async with bot.conversation(chat) as pw:
            await event.respond("**➽ Limit Quota (GB):**")
            pw = await pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = pw.raw_text

        async with bot.conversation(chat) as exp:
            await event.respond('**➽ Expiry In :**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" | /usr/local/bin/bot/add-vless-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"Terjadi kesalahan: {e}\nSubproses output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        x = [x.group() for x in re.finditer("vless://(.*)", a)]
        print(x)
        uuid = re.search("vless://(.*?)@", x[0]).group(1)
        msg = f"""
**━━━━━━━━━━━━━━━━━━━━━**
          🍀 𝐗𝐑𝐀𝐘 𝐕𝐋𝐄𝐒𝐒 𝐂𝐑𝐄𝐀𝐓𝐄𝐃 🍀 
**━━━━━━━━━━━━━━━━━━━━━**
➱ Remarks   : {user}
➱ Domain    : {DOMAIN}
➱ Quota     : {pw} GB
➱ Port TLS  : 443
➱ Port NTLS : 80, 8880
➱ User ID   : {uuid}
➱ Alter ID  : 0
➱ Security  : auto
➱ Path WS   : /vlessws
➱ Path gRPC : vless-grpc
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VLESS WS TLS ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[0]}```
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VLESS WS NTLS ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[1].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VLESS gRPC ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[2].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━**
** ➽ 𝐄𝐗𝐏𝐈𝐑𝐄𝐃 𝐀𝐂𝐂𝐎𝐔𝐍𝐓 : {later}**
**━━━━━━━━━━━━━━━━━━━━━**
"""
        await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await create_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')
        
#############################################################################
###                              RENEW VLESS (ADMIN)                      ###
#############################################################################	
@bot.on(events.CallbackQuery(data=b'renew-vless1'))
async def ren_vless(event):
    async def ren_vless_(event):
        # Meminta username pengguna
        async with bot.conversation(chat) as user_conv:
            await event.respond('**❐ INFO :\nHarap Input username\nakun 𝗩𝗟𝗘𝗦𝗦 dengan benar,\nJika salah input itu resiko.\n\n➥ Silahkan Input Username :**')

            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text

        async with bot.conversation(chat) as exp:
            await event.respond('**➥ Expiry In :**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        cmd = f'printf "%s\n" "{user}" "{exp}" | /usr/local/bin/bot/renew-vless-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Not Found**")
        else:
            msg = f"""**{a}**"""
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await ren_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

#############################################################################
###                          CHECK MEMBER VLESS (ADMIN)                   ###
#############################################################################	
# CEK member VLESS
@bot.on(events.CallbackQuery(data=b'listvless'))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'bash /usr/local/bin/bot/member-vless'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.respond(f"""
```
{z}
```
""", buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await cek_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


#############################################################################
###                              DELETE VLESS (ADMIN)                     ###
#############################################################################	
@bot.on(events.CallbackQuery(data=b'delete-vless2'))
async def delete_vless(event):
    async def delete_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**➥ Username :**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text

        cmd = f'printf "%s\n" "{user}" | delete-vless'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Not Found**")
        else:
            msg = f"""**{a}**"""
            await event.respond(msg)


    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await delete_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')


#############################################################################
###                          VLESS TRIAL 2 jam (ADMIN)                    ###
#############################################################################	
@bot.on(events.CallbackQuery(data=b'trial-vless3'))
async def trial_vless(event):
    async def trial_vless_(event):

 # output cmd
        cmd = f'printf "%s\n" "trial`</dev/urandom tr -dc a-z0-9 | head -c4`" "1" | /usr/local/bin/bot/add-vless-bot'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**✘ User Already Exist**")
        else:
            # Mengganti masa aktif menjadi 3 jam
            now = DT.datetime.now()
            later = now + DT.timedelta(hours=2)  # Masa aktif 2 jam
            x = [x.group() for x in re.finditer("vless://(.*)", a)]
            print(x)
            remarks = re.search("#(.*)", x[0]).group(1)
            uuid = re.search("vless://(.*?)@", x[0]).group(1)
            
            msg = f"""
**━━━━━━━━━━━━━━━━━━━━━**
          🍀 𝐗𝐑𝐀𝐘 𝐕𝐋𝐄𝐒𝐒 𝐓𝐑𝐈𝐀𝐋 🍀 
**━━━━━━━━━━━━━━━━━━━━━**
➱ Remarks   : {remarks}
➱ Domain    : {DOMAIN}
➱ Port TLS  : 443
➱ Port NTLS : 80
➱ User ID   : {uuid}
➱ Network   : ws
➱ Path WS   : /vlessws
➱ Path gRPC : vless-grpc
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VMESS WS TLS ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[0]}```
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VMESS WS NTLS ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[1].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━**
 ❒ VMESS gRPC ↴
**━━━━━━━━━━━━━━━━━━━━━**
```{x[2].replace(" ","")}```
**━━━━━━━━━━━━━━━━━━━━━**
** ➽ 𝐄𝐗𝐏𝐈𝐑𝐄𝐃 𝐀𝐂𝐂𝐎𝐔𝐍𝐓 : {later.strftime('%H:%M:%S')}**
**━━━━━━━━━━━━━━━━━━━━━**
        """
            await event.respond(msg)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await trial_vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

#############################################################################
###                             MENU VLESS (ADMIN)                        ###
#############################################################################	
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
    async def vless_(event):
        inline = [
[Button.inline(" 𝗧𝗿𝗶𝗮𝗹 2 𝗝𝗮𝗺 ","trial-vless3"),
Button.inline(" 𝗖𝗿𝗲𝗮𝘁𝗲 ","create-vless")],
[Button.inline(" 𝗥𝗲𝗻𝗲𝘄 ","renew-vless1"),
Button.inline(" 𝗗𝗲𝗹𝗲𝘁𝗲 ","delete-vless2")],
[Button.inline(" 𝗟𝗶𝘀𝘁 𝗠𝗲𝗺𝗯𝗲𝗿 ","listvless")],
[Button.inline("‹ Back Menu ›","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**𝚂𝙴𝚁𝚅𝙴𝚁 𝙸𝙽𝙵𝙾**
- 𝐃𝐨𝐦𝐚𝐢𝐧 : {DOMAIN}
- 𝐑𝐞𝐠𝐢𝐨𝐧 : {z["country"]}

**𝚇𝚛𝚊𝚢 𝚅𝚕𝚎𝚜𝚜 𝙼𝚎𝚗𝚞**
- Vless WS TLS
- Vless WS NTLS
- Vless gRPC TLS

𝚁𝚞𝚕𝚎𝚜:
- Max 2 Login
- Max 3x Peringatan (Penggantian UUID)
- Peringatan 4x Banned
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await vless_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

