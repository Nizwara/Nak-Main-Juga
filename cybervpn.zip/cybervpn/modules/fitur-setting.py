from cybervpn import *
import requests
import subprocess
import time
import os

#############################################################################
###                                  (ADMIN)                              ###
#############################################################################

@bot.on(events.CallbackQuery(data=b'reboot'))
async def reboot(event):
    user_id = str(event.sender_id)
    async def reboot_(event):
        cmd = 'reboot'
        subprocess.check_output(cmd, shell=True)
        await event.edit("""
**ʀᴇʙᴏᴏᴛ ꜱᴇʀᴠᴇʀ ʙᴇʀʜᴀꜱɪʟ ...**
""", buttons=[[Button.inline(" 🔙 Main Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await reboot_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')


#############################################################################
###                                  (ADMIN)                              ###
#############################################################################

@bot.on(events.CallbackQuery(data=b'skt-restart-service'))
async def resx(event):
    user_id = str(event.sender_id)
    async def resx_(event):
        cmd = f'systemctl restart nginx | systemctl restart xray | systemctl restart haproxy | systemctl restart sktvpn'
        subprocess.check_output(cmd, shell=True)
        await event.edit("""
**↻ 𝖲𝖾𝗋𝗏𝗂𝖼𝖾 𝖡𝖾𝗋𝗁𝖺𝗌𝗂𝗅 𝖣𝗂 𝖱𝖾𝗌𝗍𝖺𝗋𝗍...**
""", buttons=[[Button.inline(" 🔙 Main Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await resx_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')

#############################################################################
###                                  (ADMIN)                              ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'skt-service-status'))
async def show_ssh(event):
    user_id = str(event.sender_id)

    async def show_ssh_(event):
        a = 'bash /usr/local/bin/bot/status-service'
        x = subprocess.check_output(a, shell=True).decode("utf-8")
        await event.respond(f"""
```{x}```

""", buttons=[[Button.inline(" 🔙 Main Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await show_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)

    except Exception as e:
        print(f'Error: {e}')


#############################################################################
###                                  (ADMIN)                              ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
    user_id = str(event.sender_id)
    async def backup_(event):
        cmd = 'bash /usr/local/bin/bot/backup-bot'
        try: 
            a = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
            print(f"Output from bash script: {a}")  # Log output dari bash script
        except subprocess.CalledProcessError as e:
            await event.respond(f"**Error:** {e.output.decode('utf-8')}")
        except Exception as e:
            await event.respond(f"**Unexpected Error:** {str(e)}")
        else:
            msg = f"```\nbackup data server berhasil...\n```"
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await backup_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')

#############################################################################
###                                  (ADMIN)                              ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'rest'))
async def upload(event):
    user_id = str(event.sender_id)
    async def upload_(event):
        me = await bot.get_me()
        async with bot.conversation(event.chat_id) as con:
            await event.reply('**❐ 𝗖𝗮𝗿𝗮 𝗽𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻 :\n\n1. (Reply This Chat) and Upload File .zip\n2. Lalu restore lewat script VPS di menu (Setup BOT Reseller).\n3. Setelah itu Restart BOT Reseller nya.\n4. Lalu Hapus Cache dan Selesai. **')
            file = con.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            file = await file
            file = file.message.media
            file = await event.client.download_media(file, "/media/")
            path = file
            sex = "restore-bot"
            ox = subprocess.check_output(sex, shell=True).decode("utf-8")
            msg = f"{ox}"

        await event.respond("`Please Wait Proccess Restored`".format(os.path.basename(file)))
        await event.respond(msg, buttons=[[Button.inline(" 🔙 Main Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await upload_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')


#############################################################################
###                                  (ADMIN)                              ###
#############################################################################
@bot.on(events.NewMessage(pattern="(?:.restore|/restore)"))
async def rest(event):
    user_id = str(event.sender_id)
    db = get_db()

    async def rest_(event):
        if event.is_reply:
            try:
                restore = await event.client.download_media(
                    await event.get_reply_message(),
                    "cybervpn/",
                )

                if "(" not in restore:
                    path1 = Path(restore)
                    await event.respond(
                        "Uploaded To Server `{}`".format(
                            os.path.basename(restore)
                        )
                    )
                    owe = subprocess.check_output(restorebot, shell=True)
                    await event.respond(f"{owe}", buttons=[[Button.inline(" 🔙 Main Menu", "menu")]])
                else:
                    os.remove(restore)
                    await event.respond("Restore Data Failed")
            except Exception as e:
                await event.respond(str(e))
                os.remove(restore)

        await asyncio.sleep(DELETE_TIMEOUT)
        await event.delete()

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await rest_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')



#############################################################################
###                                  (ADMIN)                              ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'panel'))
async def backers(event):
    user_id = str(event.sender_id)
    async def backers_(event):
        inline = [
            [Button.inline(" 🤑 Tambah Reseller 🤑", "registrasi-member"), Button.inline(" ⛔ Hapus Reseller ⛔", "skt-delete-member")],
            [Button.inline(" 🗒️ List Member Reseller 🗒️", "skt-show-reseller")],
            [Button.inline(" ➕ 𝕋𝕒𝕞𝕓𝕒𝕙 𝕊𝕒𝕝𝕕𝕠 ➕", "skt-add-saldo")],
            [Button.inline(" 🔙 Kembali", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
━━━━━━━━━━━━━━━━━━━━
 ❐ 𝓗𝓪𝓵𝓵𝓸 𝓑𝓸𝓼 👋, 𝚂𝙰𝙻𝙰𝙼 𝙲𝚄𝙰𝙽 ❐
━━━━━━━━━━━━━━━━━━━━
        ⇲ 𝗠𝗘𝗡𝗨 𝗥𝗘𝗦𝗘𝗟𝗟𝗘𝗥 ⇱
━━━━━━━━━━━━━━━━━━━━

 ⚡ 𝙲𝚛𝚎𝚊𝚝𝚎 𝚂𝚂𝙷 𝚆𝚂
 ⚡ 𝙲𝚛𝚎𝚊𝚝𝚎 𝚇𝚛𝚊𝚢 𝚅𝚖𝚎𝚜𝚜 𝚆𝚂
 ⚡ 𝙲𝚛𝚎𝚊𝚝𝚎 𝚇𝚛𝚊𝚢 𝚅𝚕𝚎𝚜𝚜 𝚆𝚂
 ⚡ 𝙲𝚛𝚎𝚊𝚝𝚎 𝚇𝚛𝚊𝚢 𝚃𝚛𝚘𝚓𝚊𝚗 𝚆𝚂
 ⚡ 𝙲𝚛𝚎𝚊𝚝𝚎 𝚇𝚛𝚊𝚢 𝚃𝚛𝚘𝚓𝚊𝚗 GO

 ⚡ 𝚁𝚎𝚗𝚎𝚠 𝚂𝚂𝙷 𝚆𝚂
 ⚡ 𝚁𝚎𝚗𝚎𝚠 𝚇𝚛𝚊𝚢 𝚅𝚖𝚎𝚜𝚜 𝚆𝚂
 ⚡ 𝚁𝚎𝚗𝚎𝚠 𝚇𝚛𝚊𝚢 𝚅𝚕𝚎𝚜𝚜 𝚆𝚂

 **✦ Regards : 𝖩𝖺𝗇𝗀𝖺𝗇 𝖫𝗎𝗉𝖺 𝖲𝗁𝖺𝗅𝖺𝗍**
━━━━━━━━━━━━━━━━━━━━
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await backers_(event)
        else:
            await event.answer('Semvak, Akses mu Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')


#############################################################################
###                               (ADMIN)                                 ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'skt-port-status-admin'))
async def show2_essh(event):
    user_id = str(event.sender_id)

    async def show2_essh_(event):
        a = 'bash /usr/local/bin/bot/status-port'
        x = subprocess.check_output(a, shell=True).decode("utf-8")
        await event.respond(f"""
```{x}```

""", buttons=[[Button.inline(" 🔙 Main Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await show2_essh_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)

    except Exception as e:
        print(f'Error: {e}')

#############################################################################
###                                 (ADMIN)                               ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'skt-service-status-admin'))
async def show1_essh(event):
    user_id = str(event.sender_id)

    async def show1_essh_(event):
        a = 'bash /usr/local/bin/bot/status-service'
        x = subprocess.check_output(a, shell=True).decode("utf-8")
        await event.respond(f"""
```{x}```

""", buttons=[[Button.inline(" 🔙 Main Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await show1_essh_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)

    except Exception as e:
        print(f'Error: {e}')

#############################################################################
###                                  (ADMIN)                              ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'skt-setting-admin'))
async def settings(event):
    user_id = str(event.sender_id)
    async def settings_(event):
        inline = [
            [Button.inline(" 𝗣𝗢𝗥𝗧 𝗦𝗘𝗥𝗩𝗜𝗖𝗘", "skt-port-status-admin"), Button.inline("𝗖𝗛𝗘𝗖𝗞 𝗦𝗘𝗥𝗩𝗜𝗖𝗘", "skt-service-status-admin")],
            [Button.inline(" 𝗥𝗘𝗦𝗧𝗔𝗥𝗧 𝗦𝗘𝗥𝗩𝗜𝗖𝗘", "skt-restart-service"), Button.inline("𝗥𝗘𝗕𝗢𝗢𝗧 𝗦𝗘𝗥𝗩𝗘𝗥", "reboot")],
            [Button.inline(" 𝗕𝗔𝗖𝗞𝗨𝗣 𝗗𝗔𝗧𝗔", "backup"), Button.inline("𝗥𝗘𝗦𝗧𝗢𝗥𝗘 𝗗𝗔𝗧𝗔", "rest")],
            [Button.inline(" 💻 𝐏𝐀𝐍𝐄𝐋 𝐑𝐄𝐒𝐄𝐋𝐋𝐄𝐑 💻", "panel")],
            [Button.inline(" 🔙 𝐁𝐚𝐜𝐤 𝐓𝐨 𝐌𝐞𝐧𝐮", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**
━━━━━━━━━━━━━━━━━━━━━━━━
🌟 𝐓𝐎𝐎𝐋 𝗔𝗗𝗠𝗜𝗡 V1.3.25 🌟
━━━━━━━━━━━━━━━━━━━━━━━━

❏ Add Fitur Check Service
❏ Add Fitur Restart Service
❏ Add Fitur Reboot Server
❏ Add Fitur Backup BOT
❏ Add Fitur Restore BOT
❏ Add Fitur Panel Reseller

━━━━━━━━━━━━━━━━━━━━━━━━
🎭 𝗦𝗘𝗧𝗨𝗣 𝗕𝗬 @SaputraTech 🎭
━━━━━━━━━━━━━━━━━━━━━━━━
**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await settings_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')

#############################################################################
###                                (RESELLER)                             ###
#############################################################################

@bot.on(events.CallbackQuery(data=b'skt-setting-reseller'))
async def settings(event):
    user_id = str(event.sender_id)
    async def settings_(event):
        inline = [
            [Button.inline("◈ 𝗖𝗛𝗘𝗖𝗞 𝗣𝗢𝗥𝗧 ◈", "skt-port-status-user"), Button.inline("❖ 𝗖𝗛𝗘𝗖𝗞 𝗦𝗘𝗥𝗩𝗜𝗖𝗘 ❖", "skt-service-status-user")],
            [Button.inline(" 🔙 𝐁𝐚𝐜𝐤 𝐓𝐨 𝐌𝐞𝐧𝐮", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**
━━━━━━━━━━━━━━━━━━━━━━━━
🌟 𝐓𝐎𝐎𝐋 𝐑𝐄𝐒𝐄𝐋𝐋𝐄𝐑 V1.3.25 🌟
━━━━━━━━━━━━━━━━━━━━━━━━

❏ Add Fitur Check Port
❏ Add Fitur Check Service

━━━━━━━━━━━━━━━━━━━━━━━━
🎭 𝗦𝗘𝗧𝗨𝗣 𝗕𝗬 @SaputraTech 🎭
━━━━━━━━━━━━━━━━━━━━━━━━
**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await settings_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')

#############################################################################
###                                (RESELLER)                             ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'skt-port-status-user'))
async def show_essh(event):
    user_id = str(event.sender_id)

    async def show_essh_(event):
        a = 'bash /usr/local/bin/bot/status-port'
        x = subprocess.check_output(a, shell=True).decode("utf-8")
        await event.respond(f"""
```{x}```

""", buttons=[[Button.inline(" 🔙 Main Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await show_essh_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)

    except Exception as e:
        print(f'Error: {e}')

#############################################################################
###                                (RESELLER)                             ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'skt-service-status-user'))
async def show_essh(event):
    user_id = str(event.sender_id)

    async def show_essh_(event):
        a = 'bash /usr/local/bin/bot/status-service'
        x = subprocess.check_output(a, shell=True).decode("utf-8")
        await event.respond(f"""
```{x}```

""", buttons=[[Button.inline(" 🔙 Main Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await show_essh_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)

    except Exception as e:
        print(f'Error: {e}')


#############################################################################
###                                  (RESELLER)                           ###
#############################################################################
@bot.on(events.CallbackQuery(data=b'topup'))
async def show_ssh(event):
    user_id = str(event.sender_id)

    async def show_ssh_(event):
        await event.respond(f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃       🧿 MENU TOPUP 🧿      ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👤 **Author Bot:** @SaputraTech
──────────────────────────
💰 **Minimal Topup:** Rp 25.000
📝 **Catatan:**
   - Pastikan sudah mencoba trial.
   - Baca #FAQ dan #TOS sebelum melanjutkan.

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃       👑 MENU BONUS 👑      ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

👤 **Contact:** @SaputraTech
──────────────────────────
🎁 **Bonus Topup:**
   - Rp 25.000  ➔ Bonus Rp 2.000
   - Rp 40.000  ➔ Bonus Rp 4.000
   - Rp 50.000  ➔ Bonus Rp 5.000
   - Rp 100.000 ➔ Bonus Rp 15.000
──────────────────────────
""", buttons=[[Button.inline(" 🔙 Main Menu", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await show_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)

    except Exception as e:
        print(f'Error: {e}')

